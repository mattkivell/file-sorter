import os
os.chdir('G:\My Drive')
foldy = str(input(" folder name: "))
os.mkdir(foldy)
print("Folder created called {}".format(foldy)) 

    
